Windows AI SSH bootstrap bundle

1. Extract all files to a folder.
2. Open Command Prompt as Administrator and change to this folder.
3. Run: run-bootstrap-ssh.cmd
4. Paste only the connecting AI/client's PUBLIC SSH key when prompted.

The launcher checks administrator rights and execution-policy Group Policy overrides. It applies
ExecutionPolicy Bypass only to the PowerShell process that runs this script. It does not change
persistent execution policy. Stop if it reports a Group Policy override.

Default firewall source: LocalSubnet. No router or internet-facing SSH changes are made.
Review README.md before running. Never paste a private key.
